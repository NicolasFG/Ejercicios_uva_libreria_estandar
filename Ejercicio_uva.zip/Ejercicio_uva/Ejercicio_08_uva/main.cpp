#include<cstdio>
#include<iostream>

using namespace std;

int main(){
    unsigned n,i,j,k;
    unsigned blank = 0;


    cin >> n;

    while (n--){
        unsigned w,t;
        cin >> w;
        cin >> t;

        char **s = new char *[t + 1];
        auto *inv = new unsigned[t + 1];

        for (i = 0; i < t; ++i){

            s[i] = new char[w + 1];
            cin >> s[i];
            inv[i] = j = 0;
            for (; j < w; ++j){
                for (k = j + 1; k < w; ++k){
                    if (s[i][j] > s[i][k])

                        ++inv[i];
                }
            }
        }

        for (i = 0; i < t - 1; ++i){
            for (j = 0; j < t - i - 1; ++j){
                if (inv[j] > inv[j+1]){

                    swap(inv[j], inv[j+1]);

                    swap(s[j], s[j+1]);
                }
            }
        }


        if (blank) printf("\n");
        blank = 1;

        for (i = 0; i < t; ++i)
            cout << s[i];
    }
    return 0;
}