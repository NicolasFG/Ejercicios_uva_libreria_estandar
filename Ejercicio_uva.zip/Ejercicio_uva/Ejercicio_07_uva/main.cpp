#include <iostream>
using namespace std;

int main() {

    int tc;
    int n;
    int t[50];

    cin >> tc;

    while(tc--){
        cin >> n;
        for(int i=0;i<n;i++){
            cin >> t[i];
        }

        int S = 0;
        bool sw;
        for(int i=0;i<n;i++){
            sw = false;
            for(int j=1;j<n-i;j++){
                if(t[j]<t[j-1]){
                    int temp = t[j];
                    t[j] = t[j-1];
                    t[j-1] = temp;
                    S++;
                    sw = true;
                }
            }
            if(!sw) break;
        }
        cout << "Optimal train swapping takes " << S << " swaps." <<endl;
    }

    return 0;
}